/**
 * 
 */
package cestar.lambton.dao;
	
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import cestar.lambton.model.User;


/**
 * 
 */
public class UserDAO {
	private static final String DB_URL = "jdbc:mysql://localhost:3306/Users";
    private static final String DB_USER = "rootnew";
    private static final String DB_PASS = "Rahul@123";
    private static Connection conn = DatabaseConnection.getConnection(DB_URL,DB_USER,DB_PASS);
	/**
	 * 
	 */
		public static boolean saveUser(User user) {
			 try {
			        String query = "INSERT INTO User (UserName, Password, Email, Contact, City) VALUES (?, ?, ?, ?, ?)";
			        PreparedStatement preparedStatement = conn.prepareStatement(query);
			        preparedStatement.setString(1, user.getUserName());
			        preparedStatement.setString(2, user.getPassword());
			        preparedStatement.setString(3, user.getEmail());
			        preparedStatement.setString(4, user.getContact());
			        preparedStatement.setString(5, user.getCity());

			        int rowsAffected = preparedStatement.executeUpdate();
			        return rowsAffected > 0;
			    } catch (SQLException e) {
			        e.printStackTrace();
			        return false;
			    }
}
	public static boolean validateUser(String username, String password) {
		PreparedStatement preparedStatement = null;
	    ResultSet resultSet = null;

	    try {
	        String query = "SELECT * FROM User WHERE UserName = ? AND Password = ?";
	        preparedStatement = conn.prepareStatement(query);
	        preparedStatement.setString(1, username);
	        preparedStatement.setString(2, password);

	        resultSet = preparedStatement.executeQuery();
	        return resultSet.next(); // Returns true if a matching user is found, otherwise false.
	    } catch (SQLException e) {
	        e.printStackTrace();
	        return false;
	    } finally {
	        // Close the database resources (PreparedStatement and ResultSet) but don't close the connection here.
	        // Connection should be managed at a higher level.
	        try {
	            if (resultSet != null) {
	                resultSet.close();
	            }
	            if (preparedStatement != null) {
	                preparedStatement.close();
	            }
	        } catch (SQLException e) {
	            e.printStackTrace();
	        }
	    }
	}
}
