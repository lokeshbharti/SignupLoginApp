package cestar.lambton.servlets;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import cestar.lambton.dao.UserDAO;

/**
 * Servlet implementation class LoginServlet
 */
@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String username = request.getParameter("username");
        String password = request.getParameter("password");

        // Validate the user against the database (use UserDAO)
        if (UserDAO.validateUser(username, password)) {
            // If the user is valid, create a session
            HttpSession session = request.getSession();
            session.setAttribute("username", username);
            response.sendRedirect("login_success.jsp");
        } else {
            // If login fails, redirect to the login page with an error message
            response.sendRedirect("login.jsp?error=Invalid%20credentials");
        }
    }

}
